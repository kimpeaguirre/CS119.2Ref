#There should be a comma between a and b
#and the output shall be printed by puts
def multiply (a,b)
	ans = a * b
	puts ans
end