#There should be a "" in puts

if 1 < 2
	print "I'm getting printed because one is less than two!"
end

else
	print "That means I'll get printed!"
end