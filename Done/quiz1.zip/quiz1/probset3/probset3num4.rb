#it prints "525600"
