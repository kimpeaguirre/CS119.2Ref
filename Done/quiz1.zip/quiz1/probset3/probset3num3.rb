#it prints "y or z"
