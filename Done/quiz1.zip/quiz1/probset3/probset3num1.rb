#It prints "Sometimes I go beep beep"
