#it prints "nice"
